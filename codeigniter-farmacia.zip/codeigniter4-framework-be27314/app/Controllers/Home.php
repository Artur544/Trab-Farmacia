<?php

namespace App\Controllers;
use App\Models\FarmaciaModel;

class Home extends BaseController
{
    public function index(): string
    {
        return view('index');
    }
    public function registraForm(): string
    {
        return view('registraForm');
    }
    public function recebaDados()
    {
        $data = array(
            'nome' => $this->request->getVar('nome_input'),
            'laboratorio' => $this->request->getVar('laboratorio_input'),
            'preco' => $this->request->getVar('preco_input'),
            'quantidade' => $this->request->getVar('quantidade_input')
        );

        $farmacia_model = new FarmaciaModel;        
        $farmacia_model->insert($data);
        //$this->session->setFlashdata('success','Dados inseridos com sucesso');
        return redirect()->to('/listarDados');
    
    }

    public function listarDados(): string
    {
        $farmacia_model = new FarmaciaModel;
        
        $data['dados'] = $farmacia_model->findAll();

        return view('listarDados',$data);
    }
}
<h2> Dados Farmacia </h2>

<?php
// if (session()->get('success')){
//     echo "<strong>". session()->getFlashdata('success')."</strong>";
// }
// if (session()->get('success_remove')){
//     echo "<strong>". session()->getFlashdata('success_remove')."</strong>";
// }
// if (session()->get('success_updating')){
//   echo "<strong>". session()->getFlashdata('success_updating')."</strong>";
// }
?>



<table>
  <tr>
    <th>Codigo</th>
    <th>Marca</th>
    <th>Modelo</th>
    <th>Km</th>
    <th>Preco</th>
    <th> </th>
    <th> </th>
  </tr>
  <?php

foreach ($dados as $remedio){
echo "<tr>  <td> ".$remedio['codigo']."</td>  <td>".$remedio['laboratorio']."</td> <td>".$remedio['preco']."</td> <td>".$remedio['quantidade']." </td>
<td>";
?>

<form method="post" action="/remover">
<input type="hidden" name="id_removed" value="<?=$remedio['codigo']?>">   
<button type="submit"> Remover </button>
</form>

</td><td>

<form method="get" action="/formupdate/<?=$remedio['codigo']?>">
<button type="submit"> Editar </button>
</form>


<?php
echo "</td> </tr>";
}
?>
</table>


<br><BR>
<br><BR>
<br><BR>
<br><BR>
<br><BR>

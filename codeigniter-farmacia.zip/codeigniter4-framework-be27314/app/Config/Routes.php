<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes 
 */
$routes->get('/', 'Home::index');
$routes->get('/registraForm', 'Home::registraForm');
$routes->post('/recebaDados', 'Home::recebaDados');
$routes->get('/listarDados', 'Home::listarDados'); 
